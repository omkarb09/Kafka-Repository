package com.lti.controller;


import java.util.List;

import org.json.simple.JSONArray;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lti.service.KafkaReceiver;

@RestController
@RequestMapping(value="/kafka")
public class ConsumerController {
	
	/*@GetMapping(value="/consume",produces=MediaType.APPLICATION_JSON_VALUE)
	public List<JSONArray> receiveData()
	{
		return KafkaReceiver.getData();
	}
	*/
	@CrossOrigin(origins ="http://localhost:4200")
	@GetMapping(value="/consume",produces=MediaType.APPLICATION_JSON_VALUE)
	public JSONArray receiveData()
	{
		return KafkaReceiver.getData();
	}
}
