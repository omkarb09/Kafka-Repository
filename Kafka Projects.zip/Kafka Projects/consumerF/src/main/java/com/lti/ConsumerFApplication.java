package com.lti;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConsumerFApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConsumerFApplication.class, args);
	}

}
