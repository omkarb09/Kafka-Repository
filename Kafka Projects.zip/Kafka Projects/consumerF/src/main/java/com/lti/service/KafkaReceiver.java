package com.lti.service;

import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONArray;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

@Service
public class KafkaReceiver {
	
	//private static List<JSONArray> list = new ArrayList<JSONArray>();
	private static JSONArray data;
	
	@KafkaListener(topics="demojson")
	public void listen(@Payload JSONArray message)
	{
		System.out.println(message);
		//list.add(message);
		data=message;
	}

	/*public static List<JSONArray> getData() {
		return list;
	}*/
	
	public static JSONArray getData() {
		return data;
	}
	
}
