package com.lti.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.lti.model.Item;

@RestController
@RequestMapping(value = "/kafka")
public class ProducerControllerJson {

	@Autowired
    KafkaTemplate<Long, Item> KafkaJsontemplate;
	
	@PostMapping(value ="/publish")
	public String producerJson(@RequestBody Item item)
	{
		KafkaJsontemplate.send("demojson",item);
		return "Data sent";
	}
}
