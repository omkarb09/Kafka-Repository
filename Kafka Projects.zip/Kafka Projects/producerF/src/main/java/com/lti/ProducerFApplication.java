package com.lti;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.lti.service.KafkaSender;

@SpringBootApplication
public class ProducerFApplication {
	
	@Autowired
	KafkaSender con;

	public static void main(String[] args) {
		SpringApplication.run(ProducerFApplication.class, args);
		
	}
	
	@Bean
	public void callCon()
	{
		con.sendData();
	}
	
	
}
