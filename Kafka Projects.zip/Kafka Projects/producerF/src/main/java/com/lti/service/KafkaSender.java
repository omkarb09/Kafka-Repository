package com.lti.service;

import org.json.simple.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;


import com.lti.fileRead.ReadJson;

@Component
public class KafkaSender {
	
	@Autowired
    KafkaTemplate<String,JSONArray> KafkaJsontemplate;
	
	@Autowired
	ReadJson read;
	
	public void sendData()
	{
		JSONArray arr = read.readFromFile();
		System.out.println(arr);
		KafkaJsontemplate.send("demojson","1",arr);
	}
}
