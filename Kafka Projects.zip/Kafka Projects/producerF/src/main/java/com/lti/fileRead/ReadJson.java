package com.lti.fileRead;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.stereotype.Component;


@Component
public class ReadJson 
{
	public JSONArray readFromFile()
	{
		JSONArray employeeList=null;
        JSONParser jsonParser = new JSONParser();
         
        try (FileReader reader = new FileReader(".\\resources\\client-maintainence-details.json"))
        {
            Object obj = jsonParser.parse(reader);
            employeeList = (JSONArray) obj;
            System.out.println(employeeList);  
            
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return employeeList;
	}
}
