package com.lti.config;

import java.util.Properties;

import org.springframework.stereotype.Component;

@Component
public class Config {
	public Properties props;

	public Config() 
	{
		this.props = new Properties();
		props.put("bootstrap.servers", "localhost:9092");
		props.put("acks", "all");
		props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
	}
	
	
}
