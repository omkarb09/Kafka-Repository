package com.lti.controller;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.lti.config.Config;

@RestController
@RequestMapping(value = "/kafka")
public class ProducerController {
	
	@Autowired
	Config config;
	
	@PostMapping(value = "/publish")
	public String producer(@RequestParam("id") String id,@RequestParam("message") String message)
	{
		Producer<String, String> producer = new KafkaProducer<>(config.props);
		producer.send(new ProducerRecord<String, String>("demo",id,message));
		producer.close();
		return "Message sent";
	}
}
